
// $(document).ready(function () {

//     var $publishedWork = $('.published-work');
//     $($publishedWork.attr('data-item')).show();

//     $('.menu-item').click(function () {

//         var $clicked = $(this)
//         $clicked.addClass('selected');
//         $('.menu-item').not(this).removeClass("selected");

//         $('.menu-item').each(function () {
//             var $menu = $(this);

//             if (!$menu.is($clicked)) {
//                 $($menu.attr('data-item')).hide();
//             }
//         });

//         $($clicked.attr('data-item')).show();
//     });

// });
